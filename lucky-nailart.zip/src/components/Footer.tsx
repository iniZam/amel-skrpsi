import React from 'react';
import { Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#FF7A97] text-white py-6 px-4 mt-12">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-medium">
        <div>
          <span>© {new Date().getFullYear()} Nailove. All rights reserved.</span>
        </div>

        {/* Social Icons matching reference */}
        <div className="flex items-center gap-4">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white text-white hover:text-[#FF7A97] transition-all flex items-center justify-center"
            title="Instagram"
          >
            <Instagram className="w-4 h-4" />
          </a>
          <a
            href="https://tiktok.com"
            target="_blank"
            rel="noreferrer"
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white text-white hover:text-[#FF7A97] transition-all flex items-center justify-center font-bold text-xs"
            title="TikTok"
          >
            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
              <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
            </svg>
          </a>
          <a
            href="https://youtube.com"
            target="_blank"
            rel="noreferrer"
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white text-white hover:text-[#FF7A97] transition-all flex items-center justify-center"
            title="YouTube"
          >
            <Youtube className="w-4 h-4" />
          </a>
          <a
            href="https://pinterest.com"
            target="_blank"
            rel="noreferrer"
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white text-white hover:text-[#FF7A97] transition-all flex items-center justify-center font-bold text-xs"
            title="Pinterest"
          >
            <span className="font-serif font-black italic text-sm leading-none">P</span>
          </a>
        </div>
      </div>
    </footer>
  );
}
