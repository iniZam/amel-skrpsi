import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

export interface User {
  id: number;
  username: string;
  passwordHash: string;
}

export interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  services: string[];
  date: string;
  time: string;
  status: 'pending' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface FrequentItemset {
  id: number;
  items: string[];
  support: number;
  count: number;
  k: number;
}

export interface AssociationRule {
  id: number;
  antecedent: string[];
  consequent: string[];
  support: number;
  confidence: number;
  lift: number;
}

export interface NailDesign {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category?: string;
  rating?: number;
  tag?: string;
  styleSubtitle?: string;
}

export interface DBData {
  users: User[];
  bookings: Booking[];
  transactions: string[][];
  frequent_itemsets: FrequentItemset[];
  association_rules: AssociationRule[];
  designs: NailDesign[];
  config: {
    minSupport: number;
    minConfidence: number;
    newTransactionsSinceLastTrain: number;
  };
}

export const DEFAULT_GALLERY_DESIGNS: NailDesign[] = [
  { 
    id: "Floral_Accent", 
    name: "Daisy Nude & Floral", 
    price: 130000, 
    description: "Motif daisy halus nan manis dengan dasar nude pink natural yang anggun dan feminim.", 
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop",
    category: "Cute",
    rating: 4.8,
    tag: "Populer",
    styleSubtitle: "Natural, Feminim"
  },
  { 
    id: "Nude_Gel", 
    name: "Milky White Minimalist", 
    price: 90000, 
    description: "Garis lembut minimalis bernuansa putih susu dan nude bersih yang memikat.", 
    image: "https://images.unsplash.com/photo-1607779097040-26e80aa78e66?q=80&w=600&auto=format&fit=crop",
    category: "Minimalis",
    rating: 4.7,
    tag: "Rekomendasi",
    styleSubtitle: "Bersih & Minimalis"
  },
  { 
    id: "Pastel_Ombre", 
    name: "Sugar Berry Ombre", 
    price: 125000, 
    description: "Gradasi warna berry pink manis dengan sentuhan shimmer glitter lembut berkilau.", 
    image: "https://images.unsplash.com/photo-1632345031435-8797b2d58045?q=80&w=600&auto=format&fit=crop",
    category: "Korea Style",
    rating: 4.9,
    tag: "Best Seller",
    styleSubtitle: "Manis & Berkilau"
  },
  { 
    id: "Marble_Art", 
    name: "Mocha Love & Checkered", 
    price: 150000, 
    description: "Kombinasi artistik motif hati, catur chic, dan marble hangat berkelas.", 
    image: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=600&auto=format&fit=crop",
    category: "Korea Style",
    rating: 4.6,
    tag: "Populer",
    styleSubtitle: "Hangat & Chic"
  },
  { 
    id: "French_Tips", 
    name: "French Tips Modern", 
    price: 110000, 
    description: "Sentuhan gaya klasik timeless dengan ujung putih presisi pada gel kuku sehat bercahaya.", 
    image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=600&auto=format&fit=crop",
    category: "Classic",
    rating: 4.9,
    tag: "Favorit",
    styleSubtitle: "Klasik & Abadi"
  },
  { 
    id: "Glitter_Red", 
    name: "Glitter Glam Crimson", 
    price: 120000, 
    description: "Kilauan butiran glitter rose crimson mewah untuk pesona glamor dan percaya diri.", 
    image: "https://images.unsplash.com/photo-1604654894610-df63bc536371?q=80&w=600&auto=format&fit=crop",
    category: "Glitter",
    rating: 4.8,
    tag: "Baru",
    styleSubtitle: "Kilau Mewah"
  },
  { 
    id: "Cat_Eye", 
    name: "Cat Eye Velvet Rose", 
    price: 160000, 
    description: "Efek magnetik 3D velvet deep rosy mauve dengan kilau galaksi yang memukau.", 
    image: "https://images.unsplash.com/photo-1522337094133-f30f51db0d5b?q=80&w=600&auto=format&fit=crop",
    category: "Elegant",
    rating: 5.0,
    tag: "Premium",
    styleSubtitle: "Misterius & Elegan"
  },
  { 
    id: "Gold_Foil", 
    name: "Gold Foil & Rose Quartz", 
    price: 130000, 
    description: "Aksen serpihan emas murni 24k di atas dasar rose quartz marmer transparan.", 
    image: "https://images.unsplash.com/photo-1519014816548-bf5fe059798b?q=80&w=600&auto=format&fit=crop",
    category: "Elegant",
    rating: 4.8,
    tag: "Elegan",
    styleSubtitle: "Kemewahan Emas"
  },
  { 
    id: "Chrome_Finish", 
    name: "Rose Chrome Mirror", 
    price: 140000, 
    description: "Finishing chrome mirror pantulan kaca futuristik bernuansa rose metallic lembut.", 
    image: "https://images.unsplash.com/photo-1632345031435-8797b2d58045?q=80&w=600&auto=format&fit=crop",
    category: "Colorful",
    rating: 4.7,
    tag: "Tren 2026",
    styleSubtitle: "Futuristik & Berani"
  },
  { 
    id: "Matte_Black", 
    name: "Matte Velvet Plum", 
    price: 100000, 
    description: "Lapisan akhir matte beludru warna plum gelap yang anggun, modern, dan tahan gores.", 
    image: "https://images.unsplash.com/photo-1604654894560-df2db5362536?q=80&w=600&auto=format&fit=crop",
    category: "Minimalis",
    rating: 4.6,
    tag: "Minimalis",
    styleSubtitle: "Tegas & Menawan"
  }
];

const DB_FILE = path.join(process.cwd(), 'lucky_nailart_db.json');

// Realistic sample transactions for Apriori seed data
// Valid design names: "Glitter_Red", "Nude_Gel", "Marble_Art", "Chrome_Finish", "French_Tips", "Floral_Accent", "Cat_Eye", "Matte_Black", "Gold_Foil", "Pastel_Ombre"
const SEED_TRANSACTIONS = [
  ["French_Tips", "Nude_Gel"],
  ["French_Tips", "Nude_Gel", "Floral_Accent"],
  ["Nude_Gel", "Marble_Art"],
  ["Nude_Gel", "Marble_Art", "Gold_Foil"],
  ["Chrome_Finish", "Cat_Eye"],
  ["Chrome_Finish", "Cat_Eye", "Matte_Black"],
  ["Glitter_Red", "Gold_Foil"],
  ["Glitter_Red", "Nude_Gel", "Gold_Foil"],
  ["Pastel_Ombre", "Glitter_Red"],
  ["French_Tips", "Nude_Gel", "Gold_Foil"],
  ["French_Tips", "Floral_Accent"],
  ["Nude_Gel", "Marble_Art", "Floral_Accent"],
  ["Chrome_Finish", "Matte_Black"],
  ["Cat_Eye", "Matte_Black"],
  ["Glitter_Red", "Gold_Foil", "Matte_Black"],
  ["Pastel_Ombre", "Nude_Gel"],
  ["French_Tips", "Nude_Gel", "Marble_Art"],
  ["Nude_Gel", "Chrome_Finish"],
  ["Cat_Eye", "Chrome_Finish", "Gold_Foil"],
  ["Glitter_Red", "French_Tips"],
  ["French_Tips", "Nude_Gel"],
  ["French_Tips", "Nude_Gel", "Gold_Foil"],
  ["Nude_Gel", "Marble_Art"],
  ["Nude_Gel", "Marble_Art", "Gold_Foil"],
  ["Chrome_Finish", "Cat_Eye"],
  ["Chrome_Finish", "Cat_Eye", "Matte_Black"],
  ["Glitter_Red", "Gold_Foil"],
  ["Glitter_Red", "Nude_Gel"],
  ["Pastel_Ombre", "French_Tips"],
  ["French_Tips", "Nude_Gel", "Floral_Accent"]
];

export class NailartDatabase {
  private data: DBData;

  constructor() {
    this.data = this.load();
  }

  private load(): DBData {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        // Ensure designs array is present
        if (!parsed.designs || !Array.isArray(parsed.designs) || parsed.designs.length === 0) {
          parsed.designs = DEFAULT_GALLERY_DESIGNS;
          this.saveData(parsed);
        }
        return parsed;
      } catch (err) {
        console.error("Error reading database, creating fresh one", err);
      }
    }

    // Default configuration and seed data
    const salt = bcrypt.genSaltSync(10);
    const adminPasswordHash = bcrypt.hashSync('admin123', salt);

    const initialData: DBData = {
      users: [
        {
          id: 1,
          username: 'admin',
          passwordHash: adminPasswordHash
        }
      ],
      bookings: [
        {
          id: "bk-1",
          name: "Siti Rahma",
          email: "siti@gmail.com",
          phone: "08123456789",
          services: ["French_Tips", "Nude_Gel"],
          date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // tomorrow
          time: "10:00",
          status: "pending",
          createdAt: new Date().toISOString()
        },
        {
          id: "bk-2",
          name: "Agnes Monica",
          email: "agnes@gmail.com",
          phone: "08234567890",
          services: ["Chrome_Finish", "Cat_Eye"],
          date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0], // in 2 days
          time: "14:00",
          status: "pending",
          createdAt: new Date().toISOString()
        }
      ],
      transactions: SEED_TRANSACTIONS,
      frequent_itemsets: [],
      association_rules: [],
      designs: DEFAULT_GALLERY_DESIGNS,
      config: {
        minSupport: 0.1,
        minConfidence: 0.3,
        newTransactionsSinceLastTrain: 0
      }
    };

    this.saveData(initialData);
    return initialData;
  }

  private saveData(data: DBData) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error("Failed to save database to disk", err);
    }
  }

  public get(): DBData {
    return this.data;
  }

  public update(updater: (data: DBData) => void) {
    updater(this.data);
    this.saveData(this.data);
  }

  public addBooking(booking: Omit<Booking, 'id' | 'createdAt' | 'status'>): Booking {
    const newBooking: Booking = {
      ...booking,
      id: 'bk-' + Math.random().toString(36).substr(2, 9),
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    this.update(data => {
      data.bookings.unshift(newBooking);
    });
    return newBooking;
  }

  public updateBookingStatus(id: string, status: 'pending' | 'completed' | 'cancelled'): Booking | null {
    let updatedBooking: Booking | null = null;
    this.update(data => {
      const idx = data.bookings.findIndex(b => b.id === id);
      if (idx !== -1) {
        data.bookings[idx].status = status;
        updatedBooking = data.bookings[idx];

        // If a booking is completed, automatically add its services as a transaction
        if (status === 'completed' && updatedBooking.services.length > 0) {
          // Add transaction
          data.transactions.push(updatedBooking.services);
          data.config.newTransactionsSinceLastTrain += 1;
        }
      }
    });
    return updatedBooking;
  }

  public addTransaction(items: string[]): number {
    let newCount = 0;
    this.update(data => {
      data.transactions.push(items);
      data.config.newTransactionsSinceLastTrain += 1;
      newCount = data.config.newTransactionsSinceLastTrain;
    });
    return newCount;
  }

  public saveTrainingResults(frequent: FrequentItemset[], rules: AssociationRule[]) {
    this.update(data => {
      data.frequent_itemsets = frequent;
      data.association_rules = rules;
      data.config.newTransactionsSinceLastTrain = 0; // Reset counter after training
    });
  }

  public getDesigns(): NailDesign[] {
    return this.data.designs || DEFAULT_GALLERY_DESIGNS;
  }

  public addDesign(design: Omit<NailDesign, 'id'> & { id?: string }): NailDesign {
    const id = design.id && design.id.trim()
      ? design.id.trim().replace(/\s+/g, '_')
      : 'Art_' + Math.random().toString(36).substr(2, 6);

    const newDesign: NailDesign = {
      id,
      name: design.name.trim(),
      price: Number(design.price) || 100000,
      description: design.description || '',
      image: design.image || 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=600&auto=format&fit=crop',
      category: design.category || 'Minimalis',
      rating: design.rating ? Number(design.rating) : 4.8,
      tag: design.tag || 'Populer',
      styleSubtitle: design.styleSubtitle || 'Trendy & Cantik'
    };

    this.update(data => {
      if (!data.designs) data.designs = [...DEFAULT_GALLERY_DESIGNS];
      // Check if id already exists, if so append unique suffix
      let finalId = newDesign.id;
      let counter = 1;
      while (data.designs.some(d => d.id === finalId)) {
        finalId = `${newDesign.id}_${counter++}`;
      }
      newDesign.id = finalId;
      data.designs.unshift(newDesign);
    });

    return newDesign;
  }

  public updateDesign(id: string, updated: Partial<NailDesign>): NailDesign | null {
    let updatedItem: NailDesign | null = null;
    this.update(data => {
      if (!data.designs) data.designs = [...DEFAULT_GALLERY_DESIGNS];
      const idx = data.designs.findIndex(d => d.id === id);
      if (idx !== -1) {
        data.designs[idx] = {
          ...data.designs[idx],
          ...updated,
          id: id // preserve ID
        };
        updatedItem = data.designs[idx];
      }
    });
    return updatedItem;
  }

  public deleteDesign(id: string): boolean {
    let deleted = false;
    this.update(data => {
      if (!data.designs) data.designs = [...DEFAULT_GALLERY_DESIGNS];
      const initialLen = data.designs.length;
      data.designs = data.designs.filter(d => d.id !== id);
      if (data.designs.length < initialLen) {
        deleted = true;
      }
    });
    return deleted;
  }

  public resetDesigns(): NailDesign[] {
    this.update(data => {
      data.designs = [...DEFAULT_GALLERY_DESIGNS];
    });
    return DEFAULT_GALLERY_DESIGNS;
  }
}

export const db = new NailartDatabase();
